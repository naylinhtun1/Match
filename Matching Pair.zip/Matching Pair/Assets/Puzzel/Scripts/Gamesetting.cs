﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gamesetting : MonoBehaviour
{
    private int _setting;
    private const int settingnumber = 2;

  public enum PairNumber
    {
        NotSet =0,
        Easy = 7,
        Medium = 13,
        Expect = 20,
    }
    public enum Puzzlecategories
    {
        NotSet,
        Forest,
        Beach
    }
    public struct Settings
    {
        public PairNumber PairNumber;
        public Puzzlecategories Puzzlecategory;
    }
    private Settings _gameSettings;
    public static Gamesetting Instance;

    private void Awake()
    {
        if (Instance == null)
        {
            DontDestroyOnLoad(target: this);
            Instance = this;
        }
        else
        {
            Destroy(obj:this);
        }
    }

    private void Start()
    {
        _gameSettings = new Settings();
        ResetSetting();
    }

    public void SetPairNumber(PairNumber number)
    {
        if (_gameSettings.PairNumber == PairNumber.NotSet)
            _setting++;
        _gameSettings.PairNumber = number;
    }

    public void SetPuzzleCategories(Puzzlecategories cat)
    {
        if (_gameSettings.Puzzlecategory == Puzzlecategories.NotSet)
            _setting++;
        _gameSettings.Puzzlecategory = cat;

        
    }

    public PairNumber GetPairNumber()
    {
        return _gameSettings.PairNumber;
    }
    public Puzzlecategories GetPuzzlecategory()
    {
        return _gameSettings.Puzzlecategory;
    }

    public void ResetSetting()
    {
        _setting = 0;
        _gameSettings.Puzzlecategory = Puzzlecategories.NotSet;
        _gameSettings.PairNumber = PairNumber.NotSet;
    }

    public bool AllSettingReady()
    {
        return _setting == settingnumber;
    }
}
