﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PictureManager : MonoBehaviour
{
    public Picture picture;
    public Transform picspawnpoint;

    [HideInInspector]
    public List<PictureManager> PictureList;
    private void Start()
    {
        
    }

    private void Update()
    {
        
    }

    private void Spawnpicture(int rows, int columns, Vector2 Pos, Vector2 offset, bool scaledown)
    {
        for (int col = 0; col <columns; col++)
        {
            for(int row = 0; row<rows; row++)
            {
                var tempPicture = (Picture)Instantiate(picture, picspawnpoint.position, picspawnpoint.transform.rotation);
                   tempPicture.name = tempPicture.name + 'c' + col + 'r' + row;
                PictureList.Add(tempPicture);
            }
        }
       
    }
    private void MovePicture(int rows, int colums, Vector2 pos, Vector2 offset)
    {
        var index = 0;
        for (var col = 0; col< colums; col++)
        {
            for (int row = 0; row<rows; row++)
            {
                var targetPosition = new Vector3((pos.x + (offset.x * row)), 
            }
        }
    }
}
